package com.example.inclass10;

public interface NotesInterface {

    public void deleteThreads(int id);
}

